package com.cognizant.educonnect.config;

import com.cognizant.educonnect.entity.*;
import com.cognizant.educonnect.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository  userRepository;
    private final CourseRepository courseRepository;
    private final AssessmentRepository assessmentRepository;
    private final ContentRepository contentRepository;
    private final ComplianceRecordRepository complianceRepository;
    private final AuditLogRepository auditLogRepository;
    private final AuditRepository auditRepository;
    private final NotificationRepository notificationRepository;
    private final PasswordEncoder passwordEncoder;

    private static final String DEFAULT_PASSWORD = "password123";

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            log.info("Database already seeded — skipping DataInitializer");
            return;
        }

        log.info("  Seeding EduConnect database...");
        // Users
        User admin = createUser("Admin User",      "admin@educonnect.com",      Role.ADMIN);
        User teacher1 = createUser("Dr. Sarah Johnson", "sarah.johnson@educonnect.com", Role.TEACHER);
        User teacher2 = createUser("Prof. Michael Chen", "michael.chen@educonnect.com", Role.TEACHER);
        User manager  = createUser("Program Manager",  "manager@educonnect.com",  Role.PROGRAM_MANAGER);
        User compliance = createUser("Compliance Officer", "compliance@educonnect.com", Role.COMPLIANCE_OFFICER);
        User auditor  = createUser("Govt Auditor",    "auditor@educonnect.com",   Role.GOVERNMENT_AUDITOR);

        log.info("Users seeded: {} records", userRepository.count());

        //Courses
        Course javaCourse = createCourse("Introduction to Java Programming",
                "Learn core Java concepts: OOP, collections, generics, streams.",
                teacher1, LocalDate.of(2024, 1, 15), LocalDate.of(2024, 6, 15));

        Course springCourse = createCourse("Spring Boot Microservices",
                "Build production-ready REST APIs with Spring Boot 3 and Spring Security.",
                teacher1, LocalDate.of(2024, 2, 1), LocalDate.of(2024, 7, 31));

        Course dbCourse = createCourse("Database Design with MySQL",
                "Relational database concepts, SQL queries, normalisation, and JPA.",
                teacher2, LocalDate.of(2024, 1, 20), LocalDate.of(2024, 5, 20));

        Course webCourse = createCourse("Web Technologies",
                "HTML, CSS, JavaScript fundamentals and modern frontend practices.",
                teacher2, LocalDate.of(2024, 3, 1), LocalDate.of(2024, 8, 1));

        log.info("Courses seeded: {} records", courseRepository.count());

        // Contents
        createContent(javaCourse, "Java Basics - Variables & Data Types", Content.ContentType.VIDEO,
                "https://cdn.educonnect.com/java/week1-basics.mp4", 1);
        createContent(javaCourse, "Java OOP Concepts - Slides", Content.ContentType.PDF,
                "https://cdn.educonnect.com/java/oop-slides.pdf", 2);
        createContent(javaCourse, "Week 1 Quiz", Content.ContentType.QUIZ,
                "https://cdn.educonnect.com/java/week1-quiz.json", 3);

        createContent(springCourse, "Spring Boot Introduction - Video", Content.ContentType.VIDEO,
                "https://cdn.educonnect.com/spring/intro.mp4", 1);
        createContent(springCourse, "Spring Security Guide", Content.ContentType.PDF,
                "https://cdn.educonnect.com/spring/security-guide.pdf", 2);

        createContent(dbCourse, "SQL Fundamentals Video", Content.ContentType.VIDEO,
                "https://cdn.educonnect.com/db/sql-basics.mp4", 1);
        createContent(dbCourse, "ER Diagrams Reference Sheet", Content.ContentType.DOCUMENT,
                "https://cdn.educonnect.com/db/er-reference.docx", 2);

        log.info("Contents seeded: {} records", contentRepository.count());

        // Assessments
        createAssessment(javaCourse, "Java Midterm Exam",
                Assessment.AssessmentType.EXAM,
                "https://cdn.educonnect.com/java/midterm-paper.pdf",
                "Answer all questions. Time limit: 2 hours.",
                LocalDate.of(2024, 3, 15), 100, 50);

        createAssessment(javaCourse, "OOP Assignment",
                Assessment.AssessmentType.ASSIGNMENT,
                "https://cdn.educonnect.com/java/oop-assignment.pdf",
                "Implement a banking system using OOP principles.",
                LocalDate.of(2024, 2, 28), 50, 25);

        createAssessment(springCourse, "Spring Boot Project",
                Assessment.AssessmentType.PROJECT,
                "https://cdn.educonnect.com/spring/project-brief.pdf",
                "Build a RESTful API with JWT authentication.",
                LocalDate.of(2024, 6, 30), 100, 60);

        createAssessment(dbCourse, "SQL Quiz",
                Assessment.AssessmentType.QUIZ,
                null,
                "Online quiz covering SELECT, JOIN, and GROUP BY.",
                LocalDate.of(2024, 3, 1), 30, 15);

        log.info("Assessments seeded: {} records", assessmentRepository.count());

        //Compliance Records
        createCompliance(javaCourse.getCourseId(), ComplianceRecord.ComplianceType.COURSE,
                ComplianceRecord.ComplianceResult.COMPLIANT, "EDU-POL-001",
                "Course content reviewed and approved for curriculum delivery.");
        createCompliance(springCourse.getCourseId(), ComplianceRecord.ComplianceType.COURSE,
                ComplianceRecord.ComplianceResult.UNDER_REVIEW, "EDU-POL-002",
                "Awaiting approval for advanced module content.");
        createCompliance(dbCourse.getCourseId(), ComplianceRecord.ComplianceType.ASSESSMENT,
                ComplianceRecord.ComplianceResult.COMPLIANT, "EDU-POL-003",
                "Assessment format verified against examination guidelines.");

        log.info("Compliance records seeded: {} records", complianceRepository.count());

        //Audits
        Audit audit1 = Audit.builder()
                .officer(compliance)
                .scope("Q1 2024 Course Compliance Review")
                .findings("All active courses meet regulatory requirements. Minor documentation gaps in course descriptions.")
                .status(Audit.AuditStatus.COMPLETED)
                .build();
        auditRepository.save(audit1);

        Audit audit2 = Audit.builder()
                .officer(auditor)
                .scope("Annual Government Education Program Audit 2024")
                .findings("Program enrollment targets being met. Recommend expansion of Spring Boot curriculum.")
                .status(Audit.AuditStatus.IN_PROGRESS)
                .build();
        auditRepository.save(audit2);

        log.info("Audits seeded: {} records", auditRepository.count());

        // Notifications
        createNotification(admin, javaCourse.getCourseId(),
                "New course 'Introduction to Java Programming' has been published.",
                Notification.NotificationCategory.COURSE);
        createNotification(teacher1, springCourse.getCourseId(),
                "Your course 'Spring Boot Microservices' has been approved.",
                Notification.NotificationCategory.COURSE);
        createNotification(compliance, null,
                "Quarterly compliance review is due by end of month.",
                Notification.NotificationCategory.COMPLIANCE);

        log.info("Notifications seeded: {} records", notificationRepository.count());

        //IAM Audit Logs
        seedAuditLog(admin, "USER_REGISTERED", "users/" + admin.getUserId());
        seedAuditLog(teacher1, "USER_REGISTERED", "users/" + teacher1.getUserId());
        seedAuditLog(teacher2, "USER_REGISTERED", "users/" + teacher2.getUserId());
        seedAuditLog(manager, "USER_REGISTERED", "users/" + manager.getUserId());
        seedAuditLog(compliance, "USER_REGISTERED", "users/" + compliance.getUserId());
        seedAuditLog(auditor, "USER_REGISTERED", "users/" + auditor.getUserId());
        seedAuditLog(admin, "USER_LOGIN", "auth/login");
        seedAuditLog(teacher1, "USER_LOGIN", "auth/login");
        seedAuditLog(admin, "COURSE_CREATED", "courses/" + javaCourse.getCourseId());
        seedAuditLog(teacher1, "COURSE_CREATED", "courses/" + springCourse.getCourseId());
        seedAuditLog(admin, "ROLE_ASSIGNED", "users/" + compliance.getUserId() + "/role/COMPLIANCE_OFFICER");
        log.info("IAM Audit logs seeded: {} records", auditLogRepository.count());

        log.info("  Database seeding complete!");
        log.info("  Default password for all users: {}", DEFAULT_PASSWORD);
        log.info("  Seeded users:");
        log.info("    admin@educonnect.com        (ADMIN)");
        log.info("    sarah.johnson@educonnect.com (TEACHER)");
        log.info("    michael.chen@educonnect.com  (TEACHER)");
        log.info("    manager@educonnect.com       (PROGRAM_MANAGER)");
        log.info("    compliance@educonnect.com    (COMPLIANCE_OFFICER)");
        log.info("    auditor@educonnect.com       (GOVERNMENT_AUDITOR)");

    }

    //  Private helpers
    private User createUser(String name, String email, Role role) {
        User user = User.builder()
                .name(name).email(email)
                .password(passwordEncoder.encode(DEFAULT_PASSWORD))
                .role(role).status(UserStatus.ACTIVE)
                .build();
        return userRepository.save(user);
    }

    private Course createCourse(String title, String description, User teacher,
                                 LocalDate start, LocalDate end) {
        Course course = Course.builder()
                .title(title).description(description).teacher(teacher)
                .startDate(start).endDate(end)
                .status(Course.CourseStatus.ACTIVE)
                .build();
        return courseRepository.save(course);
    }

    private void createContent(Course course, String title,
                                Content.ContentType type, String fileUri, int sortOrder) {
        Content content = Content.builder()
                .course(course).title(title).type(type)
                .fileUri(fileUri).sortOrder(sortOrder)
                .status(Content.ContentStatus.ACTIVE)
                .build();
        contentRepository.save(content);
    }

    private void createAssessment(Course course, String title,
                                   Assessment.AssessmentType type, String fileUri,
                                   String instructions, LocalDate dueDate,
                                   int maxScore, int passingScore) {
        Assessment assessment = Assessment.builder()
                .course(course).title(title).type(type)
                .fileUri(fileUri).instructions(instructions)
                .dueDate(dueDate).maxScore(maxScore).passingScore(passingScore)
                .status(Assessment.AssessmentStatus.ACTIVE)
                .build();
        assessmentRepository.save(assessment);
    }

    private void createCompliance(Long entityId, ComplianceRecord.ComplianceType type,
                                   ComplianceRecord.ComplianceResult result,
                                   String notes, String policy) {
        ComplianceRecord record = ComplianceRecord.builder()
                .entityId(entityId).type(type).result(result)
                .notes(policy + " — " + notes)
                .build();
        complianceRepository.save(record);
    }

    private void createNotification(User user, Long entityId,
                                     String message, Notification.NotificationCategory category) {
        Notification notification = Notification.builder()
                .user(user).entityId(entityId).message(message)
                .category(category).status(Notification.NotificationStatus.UNREAD)
                .build();
        notificationRepository.save(notification);
    }
    private void seedAuditLog(User user, String action, String resource) {
        AuditLog entry = AuditLog.builder()
                .user(user).action(action).resource(resource).build();
        auditLogRepository.save(entry);
    }

}
