package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.CourseRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.CourseResponse;
import com.cognizant.educonnect.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
@RequiredArgsConstructor
@Tag(name = "Courses", description = "Course management APIs")
public class CourseController {

    private final CourseService courseService;

    @PostMapping
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Create a new course")
    public ResponseEntity<ApiResponse<CourseResponse>> create(@Valid @RequestBody CourseRequest request) {
        return ResponseEntity.ok(ApiResponse.success(courseService.createCourse(request), "Course created"));
    }

    @GetMapping
    @Operation(summary = "Get all courses")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(courseService.getAllCourses(), "Courses retrieved"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get course by ID")
    public ResponseEntity<ApiResponse<CourseResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(courseService.getCourseById(id), "Course retrieved"));
    }

    @GetMapping("/teacher/{teacherId}")
    @Operation(summary = "Get courses by teacher")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getByTeacher(@PathVariable Long teacherId) {
        return ResponseEntity.ok(ApiResponse.success(courseService.getCoursesByTeacher(teacherId), "Courses retrieved"));
    }

    @GetMapping("/search")
    @Operation(summary = "Search courses by title")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> search(@RequestParam String keyword) {
        return ResponseEntity.ok(ApiResponse.success(courseService.searchCourses(keyword), "Search results"));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update course")
    public ResponseEntity<ApiResponse<CourseResponse>> update(@PathVariable Long id, @Valid @RequestBody CourseRequest request) {
        return ResponseEntity.ok(ApiResponse.success(courseService.updateCourse(id, request), "Course updated"));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Archive course")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Course archived"));
    }

    @PutMapping("/{id}/restore")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Restore archived course to active")
    public ResponseEntity<ApiResponse<CourseResponse>> restore(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(courseService.restoreCourse(id), "Course restored"));
    }
}
