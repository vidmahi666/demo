package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.ComplianceRecord;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class ComplianceRecordResponse {
    private Long complianceId;
    private Long entityId;
    private ComplianceRecord.ComplianceType type;
    private ComplianceRecord.ComplianceResult result;
    private LocalDateTime recordDate;
    private String notes;
}
