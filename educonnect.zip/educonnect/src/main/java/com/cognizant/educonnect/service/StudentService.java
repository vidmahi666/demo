package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.response.StudentResponse;
import java.util.List;

public interface StudentService {
    StudentResponse getStudentById(Long id);
    StudentResponse getStudentByUserId(Long userId);
    List<StudentResponse> getAllStudents();
    StudentResponse updateStudent(Long id, com.cognizant.educonnect.dto.request.RegisterRequest req);
}
