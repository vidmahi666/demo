package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.LoginRequest;
import com.cognizant.educonnect.dto.request.RegisterRequest;
import com.cognizant.educonnect.dto.response.AuthResponse;
import com.cognizant.educonnect.entity.Student;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.entity.UserStatus;
import com.cognizant.educonnect.exception.BadRequestException;
import com.cognizant.educonnect.repository.StudentRepository;
import com.cognizant.educonnect.repository.UserRepository;
import com.cognizant.educonnect.security.JwtUtils;
import com.cognizant.educonnect.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository        userRepository;
    private final StudentRepository     studentRepository;
    private final PasswordEncoder       passwordEncoder;
    private final JwtUtils              jwtUtils;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService    userDetailsService;

    @Value("${app.jwt.expiration-ms}")
    private long jwtExpirationMs;

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        log.info("Registering new user: email={}, role={}", request.getEmail(), request.getRole());

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already registered: " + request.getEmail());
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone())
                .role(request.getRole())
                .status(UserStatus.ACTIVE)
                .build();

        user = userRepository.save(user);
        log.info("User registered with ID={}", user.getUserId());

        // Auto-create Student profile for STUDENT role
        if (user.getRole().name().equals("STUDENT")) {
            Student student = Student.builder()
                    .user(user)
                    .name(user.getName())
                    .contactInfo(user.getPhone())
                    .build();
            studentRepository.save(student);
            log.info("Student profile auto-created for userId={}", user.getUserId());
        }

        UserDetails ud = userDetailsService.loadUserByUsername(user.getEmail());
        return buildResponse(user, jwtUtils.generateToken(ud));
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt for email={}", request.getEmail());
        // This throws BadCredentialsException if wrong — caught by GlobalExceptionHandler → 401
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new BadRequestException("User not found"));

        UserDetails ud = userDetailsService.loadUserByUsername(user.getEmail());
        log.info("Login successful for userId={}", user.getUserId());
        return buildResponse(user, jwtUtils.generateToken(ud));
    }

    private AuthResponse buildResponse(User user, String token) {
        return AuthResponse.builder()
                .userId(user.getUserId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .status(user.getStatus())
                .accessToken(token)
                .expiresIn(jwtExpirationMs / 1000)
                .build();
    }
}
