package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.Content;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ContentRequest {

    @NotNull(message = "Course ID is required")
    @Positive(message = "Course ID must be a positive number")
    private Long courseId;

    @NotBlank(message = "Content title is required")
    @Size(min = 2, max = 200, message = "Title must be between 2 and 200 characters")
    private String title;

    @NotNull(message = "Content type is required")
    private Content.ContentType type;

    @NotBlank(message = "File URI is required")
    @Pattern(
            regexp = "^(https?://|s3://|/).+",
            message = "File URI must be a valid http/https URL, s3:// URI, or absolute path"
    )
    private String fileUri;

    @Size(max = 1000, message = "Description must not exceed 1000 characters")
    private String description;

    @Min(value = 0, message = "Sort order must be 0 or greater")
    private Integer sortOrder;
}
