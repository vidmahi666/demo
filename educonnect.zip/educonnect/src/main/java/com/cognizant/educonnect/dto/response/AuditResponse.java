package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Audit;
import lombok.*;

import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class AuditResponse {
    private Long auditId;
    private Long officerId;
    private String officerName;
    private String scope;
    private String findings;
    private LocalDateTime auditDate;
    private Audit.AuditStatus status;
}
