package com.cognizant.educonnect.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class GradeRequest {

    @NotNull(message = "Score is required")
    @Min(value = 0,    message = "Score cannot be negative")
    @Max(value = 1000, message = "Score cannot exceed 1000")
    private Integer score;

    @Size(max = 1000, message = "Feedback must not exceed 1000 characters")
    private String feedback;
}
