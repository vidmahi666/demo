package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.ContentRequest;
import com.cognizant.educonnect.dto.response.ContentResponse;
import com.cognizant.educonnect.entity.*;
import com.cognizant.educonnect.exception.ContentNotFoundException;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.*;
import com.cognizant.educonnect.service.ContentService;
import com.cognizant.educonnect.service.AuditLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ContentServiceImpl implements ContentService {

    private final ContentRepository contentRepository;
    private final ContentAccessRepository contentAccessRepository;
    private final CourseRepository courseRepository;
    private final StudentRepository studentRepository;
    private final AuditLogService auditLogService; // Add this line

    @Override
    @Transactional
    public ContentResponse uploadContent(ContentRequest request) {
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found"));
        Content content = Content.builder()
                .course(course).title(request.getTitle())
                .type(request.getType()).fileUri(request.getFileUri()).build();
        return mapToResponse(contentRepository.save(content));
    }

    @Override
    public ContentResponse getContentById(Long id) {
        return mapToResponse(findById(id));
    }

    @Override
    public List<ContentResponse> getContentByCourse(Long courseId) {
        List<Content> contents = contentRepository.findByCourseCourseIdAndStatus(courseId, Content.ContentStatus.ACTIVE);

        if (contents.isEmpty()) {
            // Throwing a custom exception (similar to your ResearcherException)
            throw new ContentNotFoundException("No content found for course ID: " + courseId);
        }

        return contents.stream()
                .map(this::mapToResponse)
                .toList();
    }
//    public List<ContentResponse> getContentByCourse(Long courseId) {
//        return contentRepository.findByCourseCourseIdAndStatus(courseId, Content.ContentStatus.ACTIVE)
//                .stream().map(this::mapToResponse).toList();
//    }

    @Override
    @Transactional
    public ContentResponse updateContent(Long id, ContentRequest request) {
        Content content = findById(id);
        content.setTitle(request.getTitle());
        content.setType(request.getType());
        content.setFileUri(request.getFileUri());
        return mapToResponse(contentRepository.save(content));
    }

    @Override
    @Transactional
    public void deleteContent(Long id) {
        Content content = findById(id);
        content.setStatus(Content.ContentStatus.ARCHIVED);
        contentRepository.save(content);
    }

    @Override
    @Transactional
    public ContentResponse restoreContent(Long id) {
        Content content = findById(id);
        content.setStatus(Content.ContentStatus.ACTIVE);
        return mapToResponse(contentRepository.save(content));
    }

    @Override
    @Transactional
    public void trackAccess(Long studentId, Long contentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));
        Content content = findById(contentId);
        if (!contentAccessRepository.existsByStudentStudentIdAndContentContentId(studentId, contentId)) {
            ContentAccess access = ContentAccess.builder().student(student).content(content).build();
            contentAccessRepository.save(access);

            // Log content access
            auditLogService.logAsync(studentId, "CONTENT_ACCESS", "Content ID: " + contentId);
        }
    }

    private Content findById(Long id) {
        return contentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Content not found: " + id));
    }


    private ContentResponse mapToResponse(Content c) {
        return ContentResponse.builder()
                .contentId(c.getContentId()).courseId(c.getCourse().getCourseId())
                .courseTitle(c.getCourse().getTitle()).title(c.getTitle())
                .type(c.getType()).fileUri(c.getFileUri())
                .uploadedDate(c.getUploadedDate()).status(c.getStatus()).build();
    }
}
