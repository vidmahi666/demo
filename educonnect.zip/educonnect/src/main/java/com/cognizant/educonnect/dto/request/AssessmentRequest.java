package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.Assessment;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter @Setter
public class AssessmentRequest {

    @NotNull(message = "Course ID is required")
    private Long courseId;

    @NotBlank(message = "Assessment title is required")
    @Size(min = 3, max = 200, message = "Title must be between 3 and 200 characters")
    private String title;

    @NotNull(message = "Assessment type is required")
    private Assessment.AssessmentType type;

    /** Teacher uploads question paper / resource — optional but validated when present */
    @Pattern(
        regexp = "^(https?://|s3://|/).+",
        message = "File URI must be a valid http/https URL, s3:// URI, or absolute path"
    )
    private String fileUri;

    @Size(max = 1000, message = "Instructions must not exceed 1000 characters")
    private String instructions;

    private LocalDate dueDate;

    @Min(value = 1,   message = "Max score must be at least 1")
    @Max(value = 1000, message = "Max score cannot exceed 1000")
    private Integer maxScore;

    @Min(value = 0,   message = "Passing score must be at least 0")
    private Integer passingScore;
}
