package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.RegisterRequest;
import com.cognizant.educonnect.dto.response.StudentResponse;
import com.cognizant.educonnect.entity.Student;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.StudentRepository;
import com.cognizant.educonnect.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;

    @Override
    public StudentResponse getStudentById(Long id) {
        return mapToResponse(findById(id));
    }

    @Override
    public StudentResponse getStudentByUserId(Long userId) {
        Student student = studentRepository.findByUserUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Student profile not found for user: " + userId));
        return mapToResponse(student);
    }

    @Override
    public List<StudentResponse> getAllStudents() {
        return studentRepository.findAll().stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional
    public StudentResponse updateStudent(Long id, RegisterRequest req) {
        Student student = findById(id);
        student.setName(req.getName());
        student.setContactInfo(req.getPhone());
        return mapToResponse(studentRepository.save(student));
    }

    private Student findById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + id));
    }

    private StudentResponse mapToResponse(Student s) {
        return StudentResponse.builder()
                .studentId(s.getStudentId())
                .userId(s.getUser() != null ? s.getUser().getUserId() : null)
                .name(s.getName()).dob(s.getDob()).gender(s.getGender())
                .address(s.getAddress()).contactInfo(s.getContactInfo()).status(s.getStatus()).build();
    }
}
