package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.AuditLogRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.AuditLogResponse;
import com.cognizant.educonnect.service.AuditLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/audit-logs")
@RequiredArgsConstructor
@Tag(name = "IAM Audit Logs",
        description = "Identity & Access Management audit trail. " +
                "Records all user authentication events, role changes, and access actions. " +
                "Separate from Compliance Audits (/api/compliance/audits) which track formal governance audits.")
public class AuditLogController {

    private final AuditLogService auditLogService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'COMPLIANCE_OFFICER', 'GOVERNMENT_AUDITOR')")
    @Operation(
            summary = "Record an audit log entry",
            description = "Manually create an IAM audit log entry. " +
                    "Typically called by system operations tracking user actions."
    )
    public ResponseEntity<ApiResponse<AuditLogResponse>> create(
            @Valid @RequestBody AuditLogRequest request) {
        log.info("POST /api/audit-logs - action={}, userId={}", request.getAction(), request.getUserId());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(auditLogService.create(request), "Audit log recorded"));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'COMPLIANCE_OFFICER', 'GOVERNMENT_AUDITOR')")
    @Operation(
            summary = "Get all IAM audit logs",
            description = "Returns all audit log entries sorted newest first. " +
                    "Accessible by ADMIN, COMPLIANCE_OFFICER, GOVERNMENT_AUDITOR."
    )
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getAll() {
        log.debug("GET /api/audit-logs - fetching all");
        return ResponseEntity.ok(ApiResponse.success(auditLogService.getAll(), "Audit logs retrieved"));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'COMPLIANCE_OFFICER', 'GOVERNMENT_AUDITOR')")
    @Operation(summary = "Get audit log by ID")
    public ResponseEntity<ApiResponse<AuditLogResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(auditLogService.getById(id), "Audit log retrieved"));
    }

    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'COMPLIANCE_OFFICER', 'GOVERNMENT_AUDITOR')")
    @Operation(
            summary = "Get audit logs for a specific user",
            description = "Returns all IAM events performed by or on a specific user account."
    )
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getByUser(@PathVariable Long userId) {
        log.debug("GET /api/audit-logs/user/{}", userId);
        return ResponseEntity.ok(ApiResponse.success(
                auditLogService.getByUser(userId), "Audit logs retrieved for user"));
    }

    @GetMapping("/date-range")
    @PreAuthorize("hasAnyRole('ADMIN', 'COMPLIANCE_OFFICER', 'GOVERNMENT_AUDITOR')")
    @Operation(
            summary = "Get audit logs within a date-time range",
            description = "Filter IAM audit events by timestamp range. " +
                    "Format: yyyy-MM-ddTHH:mm:ss (e.g. 2024-01-01T00:00:00)"
    )
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
        log.debug("GET /api/audit-logs/date-range from={} to={}", from, to);
        return ResponseEntity.ok(ApiResponse.success(
                auditLogService.getByDateRange(from, to), "Audit logs retrieved for date range"));
    }
}
