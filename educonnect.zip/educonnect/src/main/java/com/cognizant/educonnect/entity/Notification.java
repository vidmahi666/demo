package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity @Table(name = "notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long notificationId;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "user_id", nullable = false) private User user;
    private Long entityId;
    @Column(columnDefinition = "TEXT", nullable = false) private String message;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private NotificationCategory category;
    @Enumerated(EnumType.STRING) @Builder.Default private NotificationStatus status = NotificationStatus.UNREAD;
    @CreationTimestamp private LocalDateTime createdDate;
    public enum NotificationCategory { COURSE, ASSESSMENT, PROGRAM, COMPLIANCE, SYSTEM }
    public enum NotificationStatus   { UNREAD, READ, ARCHIVED }
}
