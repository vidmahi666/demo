package com.cognizant.educonnect.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AuditLogRequest {

    @NotNull(message = "User ID is required")
    @Positive(message = "User ID must be a positive number")
    private Long userId;

    @NotBlank(message = "Action is required")
    @Size(max = 200, message = "Action must not exceed 200 characters")
    private String action;

    @Size(max = 500, message = "Resource must not exceed 500 characters")
    private String resource;
}
