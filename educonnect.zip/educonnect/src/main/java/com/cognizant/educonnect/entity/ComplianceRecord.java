package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "compliance_records")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ComplianceRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long complianceId;
    private Long entityId;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ComplianceType type;
    @Enumerated(EnumType.STRING) private ComplianceResult result;
    @CreationTimestamp private LocalDateTime recordDate;
    @Column(columnDefinition = "TEXT") private String notes;
    public enum ComplianceType   { COURSE, ASSESSMENT, PROGRAM, CONTENT }
    public enum ComplianceResult { COMPLIANT, NON_COMPLIANT, UNDER_REVIEW, REMEDIATED }
}
