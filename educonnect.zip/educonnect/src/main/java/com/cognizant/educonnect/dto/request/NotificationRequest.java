package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.Notification;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NotificationRequest {

    @NotNull(message = "User ID is required")
    @Positive(message = "User ID must be a positive number")
    private Long userId;

    private Long entityId;

    @NotBlank(message = "Message is required")
    @Size(min = 5, max = 500, message = "Message must be between 5 and 500 characters")
    private String message;

    @NotNull(message = "Category is required")
    private Notification.NotificationCategory category;
}
