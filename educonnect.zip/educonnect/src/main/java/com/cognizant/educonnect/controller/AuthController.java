package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.LoginRequest;
import com.cognizant.educonnect.dto.request.RegisterRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.AuthResponse;
import com.cognizant.educonnect.service.AuthService;
import com.cognizant.educonnect.service.AuditLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "1. Authentication", description = "Register and login endpoints")
public class AuthController {

    private final AuthService authService;
    private final AuditLogService auditLogService;

    @PostMapping("/register")
    @Operation(summary = "Register a new user",
            description = "Creates a user account. Role must be one of: STUDENT, TEACHER, ADMIN, PROGRAM_MANAGER, COMPLIANCE_OFFICER, GOVERNMENT_AUDITOR")
    public ResponseEntity<ApiResponse<AuthResponse>> register(
            @Valid @RequestBody RegisterRequest request) {
        log.info("POST /api/auth/register - email={}", request.getEmail());
        AuthResponse response = authService.register(request);

        // Log successful registration
        auditLogService.logAsync(response.getUserId(), "USER_REGISTER", "Email: " + request.getEmail());

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(response, "User registered successfully"));
    }

    @PostMapping("/login")
    @Operation(summary = "Login and get JWT token",
            description = "Returns a Bearer token. Add it to subsequent requests as: Authorization: Bearer <token>")
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody LoginRequest request) {
        log.info("POST /api/auth/login - email={}", request.getEmail());
        AuthResponse response = authService.login(request);

        // Log successful login
        auditLogService.logAsync(response.getUserId(), "USER_LOGIN", "Email: " + request.getEmail());

        return ResponseEntity.ok(ApiResponse.success(response, "Login successful"));
    }
}
