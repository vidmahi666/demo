package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Submission;
import lombok.*;

import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class SubmissionResponse {
    private Long submissionId;
    private Long assessmentId;
    private String assessmentTitle;
    private Long studentId;
    private String studentName;
    private String fileUri;
    private LocalDateTime submissionDate;
    private Integer score;
    private String feedback;
    private Submission.SubmissionStatus status;
}
