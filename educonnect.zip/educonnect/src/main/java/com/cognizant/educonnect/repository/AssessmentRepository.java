package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.Assessment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AssessmentRepository extends JpaRepository<Assessment, Long> {
    List<Assessment> findByCourseCourseId(Long courseId);
    List<Assessment> findByStatus(Assessment.AssessmentStatus status);
    List<Assessment> findByType(Assessment.AssessmentType type);
}
