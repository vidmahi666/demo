package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Progress;
import lombok.*;

import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class ProgressResponse {
    private Long progressId;
    private Long studentId;
    private String studentName;
    private Long courseId;
    private String courseTitle;
    private Double completionPercentage;
    private String metricsJson;
    private Progress.ProgressStatus status;
    private LocalDateTime updatedAt;
}
