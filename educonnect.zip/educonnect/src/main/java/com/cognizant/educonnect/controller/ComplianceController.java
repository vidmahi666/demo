package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.AuditRequest;
import com.cognizant.educonnect.dto.request.ComplianceRecordRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.AuditResponse;
import com.cognizant.educonnect.dto.response.ComplianceRecordResponse;
import com.cognizant.educonnect.service.ComplianceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/compliance")
@RequiredArgsConstructor
@Tag(name = "Compliance", description = "Compliance and audit management APIs")
public class ComplianceController {

    private final ComplianceService complianceService;

    @PostMapping("/records")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMIN')")
    @Operation(summary = "Create compliance record")
    public ResponseEntity<ApiResponse<ComplianceRecordResponse>> createRecord(@Valid @RequestBody ComplianceRecordRequest request) {
        return ResponseEntity.ok(ApiResponse.success(complianceService.createRecord(request), "Record created"));
    }

    @GetMapping("/records")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','ADMIN')")
    @Operation(summary = "Get all compliance records")
    public ResponseEntity<ApiResponse<List<ComplianceRecordResponse>>> getAllRecords() {
        return ResponseEntity.ok(ApiResponse.success(complianceService.getAllRecords(), "Records retrieved"));
    }

    @GetMapping("/records/entity/{entityId}")
    @Operation(summary = "Get compliance records by entity")
    public ResponseEntity<ApiResponse<List<ComplianceRecordResponse>>> getByEntity(@PathVariable Long entityId) {
        return ResponseEntity.ok(ApiResponse.success(complianceService.getRecordsByEntity(entityId), "Records retrieved"));
    }

    @PostMapping("/audits")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    @Operation(summary = "Create audit")
    public ResponseEntity<ApiResponse<AuditResponse>> createAudit(@Valid @RequestBody AuditRequest request) {
        return ResponseEntity.ok(ApiResponse.success(complianceService.createAudit(request), "Audit created"));
    }

    @GetMapping("/audits")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','ADMIN')")
    @Operation(summary = "Get all audits")
    public ResponseEntity<ApiResponse<List<AuditResponse>>> getAllAudits() {
        return ResponseEntity.ok(ApiResponse.success(complianceService.getAllAudits(), "Audits retrieved"));
    }

    @PatchMapping("/audits/{id}/status")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    @Operation(summary = "Update audit status")
    public ResponseEntity<ApiResponse<AuditResponse>> updateAuditStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.success(complianceService.updateAuditStatus(id, status), "Status updated"));
    }
}
