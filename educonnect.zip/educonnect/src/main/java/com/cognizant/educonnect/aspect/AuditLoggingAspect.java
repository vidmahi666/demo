package com.cognizant.educonnect.aspect;

import com.cognizant.educonnect.service.AuditLogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Optional;

@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class AuditLoggingAspect {

    private final AuditLogService auditLogService;

    // Pointcut for all controller methods
    @Pointcut("execution(* com.cognizant.educonnect.controller.*.*(..))")
    public void controllerMethods() {}

    // Pointcut for authentication methods
    @Pointcut("execution(* com.cognizant.educonnect.controller.AuthController.*(..))")
    public void authMethods() {}

    @AfterReturning(pointcut = "controllerMethods()", returning = "result")
    public void logSuccessfulOperation(JoinPoint joinPoint, Object result) {
        try {
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            Method method = signature.getMethod();
            String className = joinPoint.getTarget().getClass().getSimpleName();
            String methodName = method.getName();

            // Skip logging for GET operations and certain methods
            if (methodName.startsWith("get") || methodName.startsWith("find") ||
                    methodName.startsWith("search") || methodName.equals("trackAccess")) {
                return;
            }

            Long userId = getCurrentUserId();
            if (userId == null) return;

            String action = buildAction(className, methodName);
            String resource = buildResource(joinPoint);

            auditLogService.logAsync(userId, action, resource);
        } catch (Exception e) {
            log.error("Failed to log audit for successful operation: {}", e.getMessage());
        }
    }

    @AfterThrowing(pointcut = "controllerMethods()", throwing = "exception")
    public void logFailedOperation(JoinPoint joinPoint, Throwable exception) {
        try {
            Long userId = getCurrentUserId();
            if (userId == null) return;

            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            Method method = signature.getMethod();
            String className = joinPoint.getTarget().getClass().getSimpleName();
            String methodName = method.getName();

            String action = "FAILED_" + buildAction(className, methodName);
            String resource = buildResource(joinPoint) + " [ERROR: " + exception.getMessage() + "]";

            auditLogService.logAsync(userId, action, resource);
        } catch (Exception e) {
            log.error("Failed to log audit for failed operation: {}", e.getMessage());
        }
    }

    @AfterReturning(pointcut = "authMethods()", returning = "result")
    public void logAuthOperations(JoinPoint joinPoint, Object result) {
        try {
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            String methodName = signature.getMethod().getName();

            String action = switch (methodName) {
                case "register" -> "USER_REGISTER";
                case "login" -> "USER_LOGIN";

                default -> "AUTH_" + methodName.toUpperCase();
            };

            // For auth operations, we might not have user context yet
            // Try to get userId from result or parameters
            Long userId = extractUserIdFromAuthResult(result, joinPoint.getArgs());

            if (userId != null) {
                auditLogService.logAsync(userId, action, null);
            }
        } catch (Exception e) {
            log.error("Failed to log auth operation: {}", e.getMessage());
        }
    }

    private Long getCurrentUserId() {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getPrincipal() instanceof org.springframework.security.core.userdetails.User userDetails) {
                // You might need to adjust this based on how you store user ID in authentication
                // For now, assuming username is the userId as String
                return Long.valueOf(userDetails.getUsername());
            }
        } catch (Exception e) {
            log.debug("Could not extract user ID from security context: {}", e.getMessage());
        }
        return null;
    }

    private String buildAction(String className, String methodName) {
        // Remove "Controller" suffix and convert to action
        String entity = className.replace("Controller", "").toUpperCase();

        return switch (methodName) {
            case "create", "upload" -> entity + "_CREATE";
            case "update" -> entity + "_UPDATE";
            case "delete" -> entity + "_DELETE";
            case "restore" -> entity + "_RESTORE";
            default -> entity + "_" + methodName.toUpperCase();
        };
    }

    private String buildResource(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        if (args.length == 0) return null;

        // Try to extract ID from path variables or request body
        for (Object arg : args) {
            if (arg instanceof Long) {
                return "ID: " + arg;
            }
            if (arg instanceof String) {
                return "Resource: " + arg;
            }
        }

        return joinPoint.getSignature().getName();
    }

    private Long extractUserIdFromAuthResult(Object result, Object[] args) {
        // Try to extract userId from method result or parameters
        // This depends on your AuthController implementation
        try {
            // Check if result has userId field
            if (result != null && result.getClass().getSimpleName().contains("Response")) {
                Optional.ofNullable(result.getClass().getMethod("getUserId"))
                        .map(method -> {
                            try {
                                return (Long) method.invoke(result);
                            } catch (Exception e) {
                                return null;
                            }
                        })
                        .orElse(null);
            }

            // Check parameters for userId
            for (Object arg : args) {
                if (arg instanceof Long) {
                    return (Long) arg;
                }
            }
        } catch (Exception e) {
            log.debug("Could not extract userId from auth result: {}", e.getMessage());
        }
        return null;
    }
}
