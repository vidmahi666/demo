package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.NotificationRequest;
import com.cognizant.educonnect.dto.response.NotificationResponse;
import java.util.List;

public interface NotificationService {
    NotificationResponse send(NotificationRequest request);
    List<NotificationResponse> getByUser(Long userId);
    NotificationResponse markAsRead(Long notificationId);
    long countUnread(Long userId);
}
