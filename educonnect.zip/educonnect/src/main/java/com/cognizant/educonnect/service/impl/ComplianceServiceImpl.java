package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.ComplianceRecordRequest;
import com.cognizant.educonnect.dto.response.ComplianceRecordResponse;
import com.cognizant.educonnect.entity.ComplianceRecord;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.dto.response.AuditResponse;
import com.cognizant.educonnect.dto.request.AuditRequest;
import com.cognizant.educonnect.entity.Audit;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.repository.ComplianceRecordRepository;
import com.cognizant.educonnect.repository.AuditRepository;
import com.cognizant.educonnect.repository.UserRepository;
import com.cognizant.educonnect.service.ComplianceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRepository;
    private final AuditRepository auditRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public ComplianceRecordResponse createRecord(ComplianceRecordRequest request) {
        ComplianceRecord r = ComplianceRecord.builder()
                .entityId(request.getEntityId())
                .type(request.getType())
                .result(request.getResult())
                .notes(request.getNotes())
                .build();
        return mapToResponse(complianceRepository.save(r));
    }
    @Override
    @Transactional
    public List<AuditResponse> getAllAudits(){
        return auditRepository.findAll().stream().map(this::mapToAuditResponse).toList();
    }
    @Override
    @Transactional
    public AuditResponse updateAuditStatus(Long id, String status){
        Audit audit = auditRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Audit not found with id: " + id));
        audit.setStatus(Audit.AuditStatus.valueOf(status.toUpperCase()));
        Audit updatedAudit = auditRepository.save(audit);
        return mapToAuditResponse(updatedAudit);
    }
    @Override
    @Transactional
    public AuditResponse createAudit(AuditRequest request) {
        User officer = userRepository.findById(request.getOfficerId())
                .orElseThrow(() -> new ResourceNotFoundException("Officer not found with id: " + request.getOfficerId()));
        Audit audit = Audit.builder()
                .officer(officer)
                .scope(request.getScope())
                .findings(request.getFindings())
                .build();
        Audit savedAudit = auditRepository.save(audit);
        return mapToAuditResponse(savedAudit);
    }
    @Override
    public List<ComplianceRecordResponse> getAllRecords() {
        return complianceRepository.findAll().stream().map(this::mapToResponse).toList();
    }

    @Override
    public List<ComplianceRecordResponse> getRecordsByEntity(Long entityId) {
        return complianceRepository.findByEntityId(entityId)
                .stream().map(this::mapToResponse).toList();
    }

    private ComplianceRecordResponse mapToResponse(ComplianceRecord r) {
        return ComplianceRecordResponse.builder()
                .complianceId(r.getComplianceId())
                .entityId(r.getEntityId())
                .type(r.getType())
                .result(r.getResult())
                .recordDate(r.getRecordDate())
                .notes(r.getNotes())
                .build();
    }

    private AuditResponse mapToAuditResponse(Audit audit) {
        return AuditResponse.builder()
                .auditId(audit.getAuditId())
                .officerId(audit.getOfficer().getUserId())
                .officerName(audit.getOfficer().getName())
                .scope(audit.getScope())
                .findings(audit.getFindings())
                .auditDate(audit.getAuditDate())
                .status(audit.getStatus())
                .build();
    }
}
